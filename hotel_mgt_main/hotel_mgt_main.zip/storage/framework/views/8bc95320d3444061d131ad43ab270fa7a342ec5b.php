

<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<link href='css/style-make-sales-drink.css' rel='stylesheet' />

<body>
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <?php echo $__env->make('header.nav-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container">
                <div class='row background-color-white padding-30px padding-left-30percent' style='width:100%;'>
                 
                          <h1>
                             Make Sales Drinks
                          </h1>
                    </div>
               <div class="row">
				<!-- Product #1 -->
                   <?php $__currentLoopData = $all_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				     <div class="col-xs-12 col-sm-6 col-md-3 product">
					<div class="product-img">
						<img  src="drink_type/<?php echo e($obj->picture); ?>" alt="Product"/>
						<div class="product-hover">
							<div class="text-center" style='padding-top:80%;'>
								<button class='text-color-white background-color-red btn margin-top-10px add-btn ' id='cart<?php echo e($obj->id); ?>' onclick='add_to_cart("drinks",<?php echo e($obj->id); ?>)'>
                                          <?php if($menu_obj->checkCart('food_type',$obj->id) == 0): ?>
                                                Add To Cart
                                          <?php elseif($menu_obj->checkCart('food_type',$obj->id) == 1): ?>
                                                Remove item From Cart
                                          <?php endif; ?>
                                </button>
							</div>
						</div>
						<!-- .product-overlay end -->
					</div>
					<!-- .product-img end -->
					<div class="product-bio">
					
						<!-- .product-cat end -->
						<div class="prodcut-title">
							<h3>
								<a href="#"><?php echo e($obj->drink_type); ?></a>
							</h3>
						</div>
						<!-- .product-title end -->
						<div class="product-price">
							<span class="symbole">&#8358;</span><span><?php echo e(number_format($obj->unit_price)); ?></span>
						</div>
						<!-- .product-price end -->
						
					</div>
					<!-- .product-bio end -->
				</div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<!-- .product end -->
				      <input type='text' id='access_token' value='<?php echo e(Session::get("token")); ?>' class='hide' />
			
				<!-- .product end -->
			</div>
			<!-- .row end -->
                    
                    
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
    

     
    </div>
    
    <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
