<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<style>

.room-detail .booking-form .form .field.rooms {
    z-index: 0;
    position: relative;
}

input[type=radio]:not(:checked) {
    left: 0;
    opacity: inherit;
    position: relative;
}

</style>
 

<body>
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <?php echo $__env->make('header.nav-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container">
                <div class='row background-color-white width-100percent padding-5px'>
                   <div class='padding-30px padding-left-30percent'>
                      <h1>
                        Customer Activities
                      </h1>
                   </div>
                    <br>
                    
                   
                    <div style='width:50%;margin-bottom:50px;margin-left:25%;'>
                        
                        <form action='customer_activities' enctype="multipart/form-data">
                        
                             <input type="text" class="form-control input-daterange-datepicker" id='date1' name='date1' placeholder="Date" title='Date' required=''>
                             
                             <br />
                             
                             <button type='submit' id='' class='btn-primary padding-5px width-100percent' >
                                 Submit &nbsp; <i class="fa fa-spinner fa-spin hide " aria-hidden="true"></i>
                             </button>
                        </form>
                            
                    </div>
                      
                      <br>
          
                    <div class="col-sm-12">
                       
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example" class="display" style='width:100%;'>
                                    <thead>
                                        <tr>
                                            <th>Customer Name</th>
                                            <th>Activity</th>
                                            <th>Amount Spent</th>
                                            <th>Date</th>
                                   
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i=0; ?>
                                        <?php $__currentLoopData = $sales_room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                            <?php $i++; ?>
                                            <tr>
                                               
                                                <td><?php echo e($obj->getCustomerName($data->customer_id)); ?></td>
                                                <td>Room Booking</td>
                                                <td>&#8358;<?php echo e(number_format($data->amount)); ?></td>
                                                <td><?php echo e(date('d-m-Y',strtotime($data->created_at))); ?></td>
                                                
                                               
                                            </tr>
                                                
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                         <?php $__currentLoopData = $sales_drink; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                           
                                            <tr>
                                               
                                                <td><?php echo e($obj->getCustomerName($data->customer_id)); ?></td>
                                                <td>Bought Drinks</td>
                                                <td>&#8358;<?php echo e(number_format($data->price * $data->qty)); ?></td>
                                                <td><?php echo e(date('d-m-Y',strtotime($data->created_at))); ?></td>
                                                
                                               
                                            </tr>
                                                
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                         <?php $__currentLoopData = $sales_res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                           
                                            <tr>
                                               
                                                <td><?php echo e($obj->getCustomerName($data->customer_id)); ?></td>
                                                <td>Bought Food</td>
                                                <td>&#8358;<?php echo e(number_format($data->price * $data->qty)); ?></td>
                                                <td><?php echo e(date('d-m-Y',strtotime($data->created_at))); ?></td>
                                                
                                               
                                            </tr>
                                                
                                       
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <?php $__currentLoopData = $sales_pool; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                           
                                            <tr>
                                               
                                                <td><?php echo e($obj->getCustomerName($data->customer_id)); ?></td>
                                                <td>Pool payment</td>
                                                <td>&#8358;<?php echo e(number_format($data->cost)); ?></td>
                                                <td><?php echo e(date('d-m-Y',strtotime($data->created_at))); ?></td>
                                                
                                               
                                            </tr>
                                                
                                       
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>Customer Name</th>
                                            <th>Activity</th>
                                            <th>Amount Spent</th>
                                            <th>Date</th>
                                        </tr>
                                    </tfoot>
                                </table>
                                    
                                <input type='text' id='access_token' value='<?php echo e(Session::get("token")); ?>' class='hide' />
                                    
                                <div class='pull-right'>
                                      <?php if($paging !=null && count($paging) > 0): ?>
                                            <?php echo e($paging->links()); ?>

                                      <?php endif; ?>
                                </div>

                                </div>
                            </div>
                        </div>
                    </div>
      

                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
      
     
    </div>
    
    <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    
    
  