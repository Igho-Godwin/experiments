<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 

<body>
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <?php echo $__env->make('header.nav-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container">
                <div class='row background-color-white width-100percent padding-5px'>
                   <div class='padding-30px padding-left-30percent'>
                      <h1>
                        All Sold Rooms
                      </h1>
                   </div>
                    <br>
                    <div class="col-sm-12">
                                      <br>
                          <div style='width:50%;margin-left:auto;margin-right:auto;'>
                            
                         
                            <form id='search-form' action='allSoldRooms' method='get' >
                                    <div id='error' style='color:red;'>
                           
                                    </div>
                                    <div class="form-row">
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control input-daterange-datepicker" id='date1' name='date1' value='<?php echo e(Request::get("date1")); ?>' placeholder="Date" title='Date' required=''>
                             
                                            <br />
                                        </div>
                                        <div class='col-sm-6'>
                                            
                                            <button type='submit' id='' class='btn padding-5px text-center' style='height:50px;background-color:#337ab7;color:white;' onclick='GetProfit()' >
                                                Search &nbsp; <i class="fa fa-spinner fa-spin hide " aria-hidden="true"></i>
                                            </button>
                            
                                        </div>
                                    </div>
                   
                       
                            </form>
                            
                   
                            <div>
                              <?php if(isset($Income)): ?>
                                Income : &#8358;<?php echo e(number_format($Income)); ?> &nbsp; &nbsp; number of Sales : <?php echo e($sales_total); ?> 
                              <?php endif; ?>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example" class="display" style='width:100%;'>
                                    <thead>
                                        <tr>
                                            <th>Room Type</th>
                                            <th>Room No</th>
                                            <th>Arrival Date</th>
                                            <th>Leave Date</th>
                                            <th>Amount</th>
                                            <th>Added By</th>
                                            <th>Registration Date</th>
                                            <th class='ed'>Edit</th>
                                            <th class='ed'>delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $all_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <tr>
                                              <td><?php echo e($room_obj->getRoomName($data->room_id)); ?></td>
                                              <td><?php echo e($data->room_no); ?></td>
                                              <td><?php echo e(date('d-m-Y',strtotime($data->arrival_date))); ?></td>
                                              <td><?php echo e(date('d-m-Y',strtotime($data->leave_date))); ?></td>
                                              <td><?php echo e($data->amount); ?></td>
                                              <td><?php echo e($user->getName($data->added_by)); ?></td>
                                              <td><?php echo e(date('d-m-Y H:i:s',strtotime($data->updated_at))); ?></td>
                                              <td class='ed'>
                                                <a href='editSoldRoom?id=<?php echo e($data->id); ?>'>Edit</a>   
                                              </td>
                                              <td class='ed'>
                                                  <a href='#' onClick='deleteSoldRooms(<?php echo e($data->id); ?>)'>Delete</a> 
                                              </td>
                                           </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>Room Type</th>
                                            <th>Room No</th>
                                            <th>Arrival Date</th>
                                            <th>Leave Date</th>
                                            <th>Amount</th>
                                            <th>Added By</th>
                                            <th>Registration Date</th>
                                            <th class='ed'>Edit</th>
                                            <th class='ed'>delete</th>
                                        </tr>
                                    </tfoot>
                                </table>
                                    
                                <input type='text' id='access_token' value='<?php echo e(Session::get("token")); ?>' class='hide' />
                                    
                                <div class='pull-right'>
                                    <?php if($all_items !=null && count($all_items) > 0): ?>
                                            <?php echo e($all_items->links()); ?>

                                    <?php endif; ?>
                                </div>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
    

     
    </div>
    
    <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
  