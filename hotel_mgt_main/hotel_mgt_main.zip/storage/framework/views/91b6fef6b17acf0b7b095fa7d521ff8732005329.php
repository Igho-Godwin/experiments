
<link href="css/style2.css" rel="stylesheet">
<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 

<body>
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <?php echo $__env->make('header.nav-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container">
                <div class='row background-color-white width-100percent padding-5px'>
                   <div class='padding-30px'>
                      <h1 class='text-center'>
                        Shopping Cart
                      </h1>
                      
                   </div>
                
                    <br>
                <div class="col-xs-12  col-sm-12  col-md-12">
                    <form id='cart-form' > 
                       <div >   
                        <div class='pull-left' style='margin-bottom:30px;'>
                             <select name='hotel_customer' class='form-control'>
                                 <option value=''>Select An Hotel Customer</option>
                                 <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value='<?php echo e($val->customer_id); ?>'><?php echo e($obj->getCustomerName($val->customer_id)); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </select>
                        </div>
                        <div class='pull-right' style='margin-bottom:30px;'>
                             <button class='text-color-white background-color-red btn margin-top-10px ' onclick='ClearCart()'>
                                Clear Cart
                            </button>
                        </div>
                    </div>
                       <br>
                       
					   <div class="cart-table table-responsive" style='overflow:auto;'>
                
						<table class="table table-bordered">
							<thead>
								<tr class="cart-product">
									<th class="cart-product-item">Product</th>
									<th class="cart-product-price">Price</th>
									<th class="cart-product-quantity">Quantity</th>
									<th class="cart-product-total">Total</th>
								</tr>
							</thead>
							<tbody>
                                
                              
                                <?php
                                
                                   $food_iterator = 0; $drinks_iterator =0; $max_food = 0; $min_food =0; $overall_price =0; 
                                   
                                   $max_drinks =0 ; $min_drinks =0; $iterator=0; $max=0; $min=0;
                                
                                ?>
                                
                                <?php if( Session::get('type') != null): ?>
                                
                                  <?php $__currentLoopData = Session::get('type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     
                                     <?php $iterator++; ?>
                                     
                                    <?php if($iterator == 1): ?>
                                          <?php $min = $key; ?>
                                    <?php endif; ?>
                                     
                                    <?php if($val == 'food_type' ): ?>
                                        
                                        
                                        
                                        <?php $obj =  $menu_obj->getFoodDetails(Session::get('cart')[$key]); $id=Session::get('cart')[$key]  ?>
                                    <?php if(isset($obj)): ?>
                                       <?php $food_iterator++; ?>
                                
                                    <?php if($food_iterator == 1): ?>
                                          <?php $min_food = $key; ?>
                                    <?php endif; ?>
                                    <?php
                                
                                        $price_food = $obj->price * Session::get('qty')[$key];
                                
                                    ?>
								        <tr class="cart-product" id='cart<?php echo e(Session::get("cart")[$key]); ?>'>
									       <td class="cart-product-item">
                                              <div class='pull-right'>
											    <button type='button' class='text-color-white background-color-red btn margin-top-10px add-btn ' onclick='removeFromCart("food_type",<?php echo e($id); ?>)'>Remove Item</button>
										      </div>
										  <div class="cart-product-img">
                                              <img src="food_pic/<?php echo e($obj->picture); ?>" class='' alt="product" width='200' height='200'>
										  </div>
										  <div class="cart-product-name">
                                              <h6><?php echo e($obj->name); ?></h6>
										  </div></td>
                                            <td class="cart-product-price" >&#8358;<span><?php echo e(number_format($obj->price)); ?></span></td>
									       <td class="cart-product-quantity"><div class="product-quantity">
											<a href="javascript:void(0);" id='minus-<?php echo e($key); ?>' onclick='reduce_cart_qty(<?php echo e($key); ?>)'><i class="fa fa-minus" ></i></a>
											<input type="text" value="<?php echo e(Session::get('qty')[$key]); ?>" name='qty_<?php echo e($key); ?>' readonly=''  id='qty-field-<?php echo e($key); ?>'>
											<a href="javascript:void(0);" id='plus-<?php echo e($key); ?>' onclick='add_cart_qty(<?php echo e($key); ?>)' ><i class="fa fa-plus"></i></a>
										</div></td>
                                            <td class="cart-product-total" >&#8358;<span id='total-<?php echo e($key); ?>'><?php echo e(number_format($price_food)); ?></span></td>
								        </tr>
                                        <input type='text' class='hide' id='price-<?php echo e($key); ?>' value='<?php echo e($obj->price); ?>' />
                                        <input type='text' class='hide'  name='food_<?php echo e($key); ?>' value="<?php echo e(Session::get('cart')[$key]); ?>" />
                                        <input type='text' class='hide'  name='price_<?php echo e($key); ?>' value='<?php echo e($obj->price); ?>' />
                                
                                        <?php $max_food = $key; ?>
                                
                                        <?php $overall_price += $price_food; ?> 
                                      
                                        
                                   <?php endif; ?>
                                    <?php endif; ?>
                                
                                    <?php if($val == 'drinks' ): ?>
                                        
                                        
                                        
                                        <?php $obj =  $menu_obj->getDrinkDetails(Session::get('cart')[$key]); $id=Session::get('cart')[$key]  ?>
                                    <?php if(isset($obj)): ?>
                                       <?php $drinks_iterator++; ?>
                                
                                    <?php if($drinks_iterator == 1): ?>
                                          <?php $min_drinks = $key; ?>
                                    <?php endif; ?>
                                
                                     <?php
                                
                                        $price_drink = $obj->unit_price * Session::get('qty')[$key];
                                
                                    ?>
								        <tr class="cart-product" id='cart<?php echo e(Session::get("cart")[$key]); ?>'>
									       <td class="cart-product-item">
									           <div class="cart-product-img">
                                              <img src="drink_type/<?php echo e($obj->picture); ?>" class='' alt="product" width='200' height='200'>
										  </div>
										    <div class="cart-product-name">
                                              <h6><?php echo e($obj->drink_type); ?></h6>
										  </div>
                                              <div class='pull-right'>
											    <button class='text-color-white background-color-red btn margin-top-10px add-btn ' onclick='removeFromCart("drinks",<?php echo e($id); ?>)'>Remove Item</button>
										      </div>
										  
										</td>
                                            <td class="cart-product-price" >&#8358;<span><?php echo e(number_format($obj->unit_price)); ?></span></td>
									       <td class="cart-product-quantity"><div class="product-quantity">
											<a href="javascript:void(0);" id='minus-<?php echo e($key); ?>' onclick='reduce_cart_qty(<?php echo e($key); ?>)'><i class="fa fa-minus" ></i></a>
											<input type="text" value="<?php echo e(Session::get('qty')[$key]); ?>"  name='qty_<?php echo e($key); ?>' readonly=''  id='qty-field-<?php echo e($key); ?>'>
											<a href="javascript:void(0);" id='plus-<?php echo e($key); ?>' onclick='add_cart_qty(<?php echo e($key); ?>)' ><i class="fa fa-plus"></i></a>
										</div></td>
                                            <td class="cart-product-total" >&#8358;<span id='total-<?php echo e($key); ?>'><?php echo e(number_format($price_drink)); ?></span></td>
								        </tr>
                                        <input type='text' class='hide' id='price-<?php echo e($key); ?>' value='<?php echo e($obj->unit_price); ?>' />
                                        <input type='text' class='hide'  name='drink_<?php echo e($key); ?>' value="<?php echo e(Session::get('cart')[$key]); ?>" />
                                        <input type='text' class='hide'  name='price_<?php echo e($key); ?>' value='<?php echo e($obj->unit_price); ?>' />
                                
                                        <?php $max_drinks = $key; ?>
                                
                                        <?php $overall_price += $price_drink; ?> 
                                      
                                        
                                   <?php endif; ?>
                                    <?php endif; ?>
                                
                                     <?php $max = $key; ?>
                                   
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                                 <?php endif; ?>
                                
                                   <input type='text' class='hide'  name='max_food' id='max_food' value="<?php echo e($max_food); ?>" />
                                   <input type='text' class='hide'  name='min_food' id='min_food' value='<?php echo e($min_food); ?>' />
                                
                                   <input type='text' class='hide'  name='max' id='max' value="<?php echo e($max); ?>" />
                                   <input type='text' class='hide'  name='min' id='min' value='<?php echo e($min); ?>' />
                                
                                   <input type='text' class='hide'  name='max_drinks' id='max_drinks' value="<?php echo e($max_drinks); ?>" />
                                   <input type='text' class='hide'  name='min_drinks' id='min_drinks' value='<?php echo e($min_drinks); ?>' />
                                
                                   <input type='text' class='hide'  id='real-overall-total' value="<?php echo e($overall_price); ?>" />
                                
                                    <input type='text' id='access_token' value='<?php echo e(Session::get("token")); ?>' class='hide' />
								
								
								<tr class="">
									<td colspan="4"><div class="row clearfix">
											<div class="col-sm-4 ">
												<form class="form-inline">
													<select class='form-control' name='mode_of_payment' id='mode_of_payment'>
                                                        <option value=''>Mode of Payment</option>
                                                        <option value='1'>POS</option>
                                                        <option value='2'>CASH</option>
                                                        <option value='3'>TRANSFER</option>
                                                    </select>
												</form>
											</div>
                                            
                                        <div class='col-sm-4' style='padding-left:100px;padding-top:15px;'><b>Overall Total:</b> &nbsp; &#8358;<span id='overall-total'><?php echo e(number_format($overall_price)); ?></span></div>
											<!-- .col-md-6 end -->
											<div class="col-sm-4 text-right">
												<button type='button'  class='text-color-white background-color-red btn margin-top-10px add-btn ' onclick='checkOut()' style='padding:5px;'>
                                                    Proceed To Checkout &nbsp; 
                                                    <i class="fa fa-spinner fa-spin hide " aria-hidden="true"></i>
                                                </button>
											</div>
											<!-- .col-md-6 end -->
										</div></td>
								</tr>
							</tbody>
						</table>
               

					</div>
					</form>
					<!-- .cart-table end -->
				</div>

                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
    

     
    </div>
    
    <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
  