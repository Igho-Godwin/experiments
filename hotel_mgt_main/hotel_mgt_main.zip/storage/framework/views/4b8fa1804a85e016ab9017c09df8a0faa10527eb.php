

<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<link rel='stylesheet' href='css/pearl-hotel.css' />

<link rel='stylesheet' href='css/form-dropdown.css' />

<link rel='stylesheet' href='css/default-color.css' />

<style>

.room-detail .booking-form .form .field.rooms {
    z-index: 0;
    position: relative;
}

</style>



<body>
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <?php echo $__env->make('header.nav-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container">
                <div class='row background-color-white padding-30px padding-left-30percent' style='width:100%;'>
                 
                          <h1>
                            Room Details
                          </h1>
                    </div>
                  
   <!--Start Content-->
	<div class="content">
	
		<!--Start Rooms-->
			<div class="room-detail">
				<div class="container">
					<div class="row">
						
						<div class="col-md-8">
						
							<div id="hotel-view" class="owl-carousel owl-theme">
								<div class="item"><img src="room_type_pic/<?php echo e($room_details->picture); ?>" alt=""></div>
							</div>
							
							
							<div class="what-include">
					           <?php if($room_details->tv != 0): ?>
                                
                                  <div class="include-sec text-center">
									<img src="imgs/icon-led.png" class='img-responsive' alt="" style='display:inline-block'>
									<span class='break-word'>TV LCD</span>
								  </div>
                                
                               <?php endif; ?>
                                
                               <?php if($room_details->breakfast != 0): ?>
                                
                                  <div class="include-sec text-center">
									   <img src="imgs/icon-cup.png" class='img-responsive' alt="" style='display:inline-block'>
									   <span class='break-word'>Breakfast</span>
								  </div>
                                
                               <?php endif; ?>
                                
                               <?php if($room_details->ac != 0): ?>
                                
                                  <div class="include-sec text-center">
									<img src="imgs/icon-ac.png" class='img-responsive' alt="" style='display:inline-block'>
									<span class='break-word'>Cool AC</span>
								</div>
                                
                               <?php endif; ?>
                                
				               <?php if($room_details->tub != 0): ?>
                                
                                  <div class="include-sec text-center">
									<img src="imgs/icon-ac.png" class='img-responsive' alt="" style='display:inline-block'>
									<span class='break-word'>Tub</span>
								</div>
                                
                               <?php endif; ?>
                                
                               <?php if($room_details->bed != 0): ?>
                                
                                  <div class="include-sec text-center">
									<img src="imgs/icon-ac.png" class='img-responsive' alt="" style='display:inline-block'>
									<span class='break-word'>Bed</span>
								</div>
                                
                               <?php endif; ?>
                                
                               <?php if($room_details->smoking != 0): ?>
                                
                                  <div class="include-sec text-center">
									<img src="imgs/icon-ac.png" class='img-responsive' alt="" style='display:inline-block'>
									<span class='break-word'>Smoking</span>
								</div>
                                
                               <?php endif; ?>
								
							
								
							</div>
                            
                            <div class="what-include">
					
								
								
							</div>
							
                            <!--
							
							<div class="room-descrip">
								<h5>Room Description</h5>
								<p>Semper ac dolor vitae accumsan. interdum hendrerit lacinia. Etiam eget urna augue. Aenean posuere pharetra tortor eu sodales. Aenean vitae facilisis ligula.
								<br/><br/>
								Nulla facilisi. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean vitae facilisis ligula. Quisque dictum neque in lectus cursus congue. Phasellus sodales condimentum rutrum.</p>
							</div>
							
							<div class="room-descrip">
								<h5>Room Overview</h5>
								<p>Semper ac dolor vitae accumsan. interdum hendrerit lacinia. Etiam eget urna augue. Aenean posuere pharetra tortor eu sodales. Aenean vitae facilisis ligula.</p>
							</div>
							
							
							<div class="room-overview">
								<div class="detail"><span><strong>Bed:</strong> Queen</span></div>
								<div class="detail light-gray"><span><strong>Occupancy:</strong> 2 Persons</span></div>
								<div class="detail"><span><strong>Ensuite Bathroom:</strong> Yes</span></div>
								<div class="detail light-gray"><span><strong>Free Airport Pickup:</strong> Yes</span></div>
								<div class="detail"><span><strong>Breakfast Included:</strong> Yes (Continental)</span></div>
								<div class="detail light-gray"><span><strong>Free Internet:</strong> Yes</span></div>
								<div class="detail"><span><strong>Gym Access:</strong> 24/7</span></div>
							</div>
							
                            -->
						
						</div>
						
						
						<div class="col-md-4">
						
							<div class="booking-form">
                                
								
								<div class="rating">
									<i class="icon-star-full"></i><i class="icon-star-full"></i><i class="icon-star-full"></i><i class="icon-star-full"></i><i class="icon-star-full"></i>
								</div>
								
								<div class="price">
									<span id='price' class="hide"><?php echo e($room_details->unitPrice); ?></span>
                                    <span id='dis-price' class="hide"><?php echo e($room_details->discounted_price); ?></span>
									<span>Room From Per Night</span>
									<span class="amount amt" style='display:inline-block;max-width:90%;word-wrap:break-word;'>&#8358;<?php echo e(number_format($room_details->unitPrice)); ?></span>
                                    <span class="amount amount2 hide">&#8358;<?php echo e(number_format($room_details->discounted_price)); ?></span>
                                    <span style='font-size:10px;'>View Discounted Price &nbsp; <input type='checkbox' id='discount-toggle' /></span>
                                    
									
								</div>
								
								
								<div class="form">
								    <div id='error' class='warning text-color-white' >
                                        
                                    </div>
                             
								    <input type="text" id="customer_name" class='form-control'  placeholder="Customer Name" onClick="" name="customer_name" style='margin-bottom: 10px;' value="<?php if($d!==''): ?><?php echo e($d->customer_name); ?><?php endif; ?>" />		
                                    
									<div class="field">
										<input type="text" id="datepicker" class='datepicker check_in'  placeholder="Check in Date" onClick="" name="datepicker" value="<?php if($d==''): ?>Choose A Date <?php else: ?> <?php echo e(date('d-m-Y',strtotime($d->arrival_date))); ?> <?php endif; ?>" onblur="if(this.value == '') { this.value='Choose A Date'}" onfocus="if (this.value == 'Choose A Date') {this.value=''}"/>		
									</div>
                                    
                                    <input type='text' class='hide' id='room_id' value='<?php echo e($room_details->id); ?>' />
									
									<div class="field">
										<input type="text" id="datepicker2" class='check_out datepicker'  placeholder="Check Out Date" onChange='getAvailableRooms()' name="datepicker" value="<?php if($d==''): ?>Choose A Date <?php else: ?> <?php echo e(date('d-m-Y',strtotime($d->leave_date))); ?> <?php endif; ?>" onblur="if(this.value == '') { this.value='Choose A Date'}" onfocus="if (this.value == 'Choose A Date') {this.value=''}"/>		
									</div>
                                    
                                    
									<div class="field rooms">
										<select class="form-control" id="available_room" name="available_room" title='Available Rooms'>
											<option value="">Available Rooms</option>
										</select>
									</div>
									
									<div class="field rooms">
										<select class="form-control" id="unavailable_rooms" name="unavailable_rooms" title='Un Available Rooms'>
                                            <option value="">Unavailable Rooms</option>
										</select>
									</div>
                                    
                                    <div class="field rooms">
                                        <select class='form-control' name='mode_of_payment' id='mode_of_payment'>
                                            <option value=''>Mode of Payment</option>
                                            <option value='1' <?php if($d!==''): ?><?php if($d->mode_of_payment == 1): ?>Selected <?php endif; ?> <?php endif; ?>>POS</option>
                                            <option value='2' <?php if($d!==''): ?> <?php if($d->mode_of_payment == 2): ?>Selected <?php endif; ?> <?php endif; ?>>CASH</option>
                                            <option value='3' <?php if($d!==''): ?> <?php if($d->mode_of_payment == 3): ?>Selected <?php endif; ?> <?php endif; ?>>TRANSFER</option>
                                        </select>
                                    </div>
									
                                    <?php if($d != ''): ?>
                                         <a href="javascript::void();" class="availability" onclick='editSoldRoom()'>Edit &nbsp; <i class="fa fa-spinner fa-spin hide " aria-hidden="true"></i></a>
									  
                                    <?php else: ?>
                                         <a href="javascript::void();" class="availability" onclick='sellRoom()'>Save &nbsp; <i class="fa fa-spinner fa-spin hide " aria-hidden="true"></i></a>
                                    <?php endif; ?>
									 <input type='text' id='access_token' value='<?php echo e(Session::get("token")); ?>' class='hide' />
										
								</div>
                                
                             
									
								<span id='rm-no' class='hide'><?php if($d != ''): ?><?php echo e($d->room_no); ?><?php endif; ?></span>
										
								<div class="clear"></div>	
							</div>
						
						</div>
						

					</div>
				</div>
			</div>
		<!--End Rooms-->
		
	</div>	
   <!--End Content-->
			<!-- .row end -->
                    
                    
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
 
    <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

   <?php if($d != ''): ?>
                                
                                  <script>
                                    
                                          getAvailableRooms();
                                    
                                
                                      
                                     
                                  </script>
                                
                                <?php endif; ?>
