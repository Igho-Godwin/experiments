<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<link rel='stylesheet' href='css/pearl-restaurant.css' />

<link href="fonts/pearl-icons.css" rel="stylesheet" type="text/css">


<body>
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <?php echo $__env->make('header.nav-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container">
                <div class='row background-color-white padding-30px ' style='width:100%;'>
                 
                          <h1 style='margin-left:auto;margin-right:auto;'>
                             Make Sales Restaurant
                          </h1>
                    </div>
                    
                    
                    <div class='row' > 
                        
                        <div class='col-sm-12'> 
                       
				             <div class="content">

		<div class="our-menu our-menu3">
			<div class="container">
				
				<div class="col-md-6">
				<div class="menu-sec">
					
					<div class="row">
						<div class="col-md-12">
							<div class="main-title">
							<span>Main Course</span>
							<h1>HOT DISHES</h1>
							</div>
						</div>
					</div>
					
					<div class="menu-detail">
						
						<div class="row">
							<?php $__currentLoopData = $main_course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                               <div class='col-sm-12'>
							     <div class="col-lg-3 col-md-3">
								     <?php if($val->picture != ''): ?>
                                        <img src='food_pic/<?php echo e($val->picture); ?>'  />
                                     <?php else: ?>
                                        <img src='food_pic/default-pic.jpg'  />
                                     <?php endif; ?>
                                 </div>
							
							     <div class="col-lg-9 col-md-9">
								    <div class="food-detail">
									   <span class="title"><?php echo e($val->name); ?> &nbsp;<span class="price">&#8358;<?php echo e($val->price); ?></span></span>
								    </div>
                                     
                                    <div class='text-right padding-bottom-20'>
                                      <button class='text-color-white background-color-red btn margin-top-10px add-btn ' id='cart<?php echo e($val->id); ?>' onclick='add_to_cart("food_type",<?php echo e($val->id); ?>)'>
                                          <?php if($menu_obj->checkCart('food_type',$val->id) == 0): ?>
                                                Add To Cart
                                          <?php elseif($menu_obj->checkCart('food_type',$val->id) == 1): ?>
                                                Remove item From Cart
                                          <?php endif; ?>
                                      </button>
                                    </div>
                                    
							     </div>
							 </div>
                                 
                                 
                            
				            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                        </div>
                        
                        
                            
                        <div class='pull-right'>
                            <?php if($main_course !=null && count($main_course) > 0): ?>
                                <?php echo e($main_course->links()); ?>

                            <?php endif; ?>    	
						</div>
                        
						
					</div>
					
				</div>
				
				
				
				<div class="menu-sec">
					
					<div class="row">
						<div class="col-md-12">
							<div class="main-title">
							<span>Soups & Salads</span>
							<h1>SIDE DISHES</h1>
							</div>
						</div>
					</div>
					
					<div class="menu-detail">
						
						<div class="row">
							
							<?php $__currentLoopData = $soups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <div class='col-sm-12'>
							     <div class="col-md-3">
								     <?php if($val->picture != ''): ?>
                                        <img src='food_pic/<?php echo e($val->picture); ?>'  />
                                     <?php else: ?>
                                        <img src='food_pic/default-pic.jpg'  />
                                     <?php endif; ?>
                                 </div>
							
							     <div class="col-md-9">
								    <div class="food-detail">
									   <span class="title"><?php echo e($val->name); ?> &nbsp;<span class="price">&#8358;<?php echo e($val->price); ?></span></span>
								    </div>
                                     
                                    <div class='text-right padding-bottom-20'>
                                      <button class='text-color-white background-color-red btn margin-top-10px add-btn  ' id='cart<?php echo e($val->id); ?>' onclick='add_to_cart("food_type",<?php echo e($val->id); ?>)'>
                                          <?php if($menu_obj->checkCart('food_type',$val->id) == 0): ?>
                                                Add To Cart
                                          <?php elseif($menu_obj->checkCart('food_type',$val->id) == 1): ?>
                                                Remove item From Cart
                                          <?php endif; ?>
                                        </button>
                                 </div>
                                    
							     </div>
							    </div>
                                 
                                 
                            
				            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														
						</div>	
                        
                        <div class='pull-right'>
                            <?php if($soups !=null && count($soups) > 0): ?>
                                <?php echo e($soups->links()); ?>

                            <?php endif; ?>    	
						</div>
						
					</div>
					
				</div>
				
				
				
				
				
				<div class="menu-sec">
					
					<div class="row">
						<div class="col-md-12">
							<div class="main-title">
							<span>Chefâ€™s Pick</span>
							<h1>OF THE DAY</h1>
							</div>
						</div>
					</div>
					
					<div class="menu-detail">
						
						<div class="row">
							
							<?php $__currentLoopData = $chef_pick; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
                                <div class='col-sm-12'>
							     <div class="col-md-3">
								     <?php if($val->picture != ''): ?>
                                        <img src='food_pic/<?php echo e($val->picture); ?>'  />
                                     <?php else: ?>
                                        <img src='food_pic/default-pic.jpg'  />
                                     <?php endif; ?>
                                 </div>
							
							     <div class="col-md-9">
								    <div class="food-detail">
									   <span class="title"><?php echo e($val->name); ?> &nbsp;<span class="price">&#8358;<?php echo e($val->price); ?></span></span>
								    </div>
                                     
                                    <div class='text-right padding-bottom-20'>
                                      <button class='text-color-white background-color-red btn margin-top-10px add-btn  ' id='cart<?php echo e($val->id); ?>' onclick='add_to_cart("food_type",<?php echo e($val->id); ?>)'>
                                          <?php if($menu_obj->checkCart('food_type',$val->id) == 0): ?>
                                                Add To Cart
                                          <?php elseif($menu_obj->checkCart('food_type',$val->id) == 1): ?>
                                                Remove item From Cart
                                          <?php endif; ?>
                                      </button>
                                 </div>
                                    
							     </div>
							    </div>
                                 
                                 
                            
				            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
														
						</div>	
                        
                        <div class='pull-right'>
                            <?php if($chef_pick !=null && count($chef_pick) > 0): ?>
                                <?php echo e($chef_pick->links()); ?>

                            <?php endif; ?>    	
						</div>
						
					</div>
					
				</div>
				
				
				
				
				
				</div>
				
				
				
				<div class="col-md-6">
				<div class="menu-sec">
					
					<div class="row">
						<div class="col-md-12">
							<div class="main-title">
							<span>Starter</span>
							<h1>beginning</h1>
							</div>
						</div>
					</div>
					
					<div class="menu-detail">
						
						<div class="row">
							
							<?php $__currentLoopData = $starter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
                                <div class='col-sm-12'>
							     <div class="col-md-3">
								     <?php if($val->picture != ''): ?>
                                        <img src='food_pic/<?php echo e($val->picture); ?>'  />
                                     <?php else: ?>
                                        <img src='food_pic/default-pic.jpg'  />
                                     <?php endif; ?>
                                 </div>
							
							     <div class="col-md-9">
								    <div class="food-detail">
									   <span class="title"><?php echo e($val->name); ?> &nbsp;<span class="price">&#8358;<?php echo e($val->price); ?></span></span>
								    </div>
                                     
                                    <div class='text-right padding-bottom-20'>
                                      <button class='text-color-white background-color-red btn margin-top-10px add-btn  ' id='cart<?php echo e($val->id); ?>' onclick='add_to_cart("food_type",<?php echo e($val->id); ?>)'>
                                          <?php if($menu_obj->checkCart('food_type',$val->id) == 0): ?>
                                                Add To Cart
                                          <?php elseif($menu_obj->checkCart('food_type',$val->id) == 1): ?>
                                                Remove item From Cart
                                          <?php endif; ?>
                                        </button>
                                 </div>
                                    
							     </div>
							    </div>
                                 
                                 
                                 
				            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						</div>	
                        
                        <div class='pull-right'>
                            <?php if($starter !=null && count($starter) > 0): ?>
                                <?php echo e($starter->links()); ?>

                            <?php endif; ?>    	
						</div>
						
					</div>
					
				</div>
				
				<div class="menu-sec">
					
					<div class="row">
						<div class="col-md-12">
							<div class="main-title">
							
							<h1>SPECIALS food</h1>
							</div>
						</div>
					</div>
					
					<div class="menu-detail">
						
						<div class="row">
							
							<?php $__currentLoopData = $special_food; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
							    <div class='col-sm-12'>
                            
							     <div class="col-md-3">
								     <?php if($val->picture != ''): ?>
                                        <img src='food_pic/<?php echo e($val->picture); ?>'  />
                                     <?php else: ?>
                                        <img src='food_pic/default-pic.jpg'  />
                                     <?php endif; ?>
                                 </div>
							
							     <div class="col-md-9">
								    <div class="food-detail">
									   <span class="title"><?php echo e($val->name); ?> &nbsp;<span class="price">&#8358;<?php echo e($val->price); ?></span></span>
								    </div>
                                     
                                    <div class='text-right padding-bottom-20'>
                                      <button class='text-color-white background-color-red btn margin-top-10px add-btn  ' id='cart<?php echo e($val->id); ?>' onclick='add_to_cart("food_type",<?php echo e($val->id); ?>)'>
                                          <?php if($menu_obj->checkCart('food_type',$val->id) == 0): ?>
                                                Add To Cart
                                          <?php elseif($menu_obj->checkCart('food_type',$val->id) == 1): ?>
                                                Remove item From Cart
                                          <?php endif; ?>
                                        </button>
                                 </div>
                                    
							     </div>
							     
							    </div>
                                 
                                 
                                 
                            
				            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						</div>	
                        
                        <div class='pull-right'>
                            <?php if($special_food !=null && count($special_food) > 0): ?>
                                <?php echo e($starter->links()); ?>

                            <?php endif; ?>    	
						</div>
						
						
					</div>
					
				</div>
				
				
				
				<div class="menu-sec">
					
					<div class="row">
						<div class="col-md-12">
							<div class="main-title">
							<span>Desserts</span>
							<h1>MOST DELICIOUS</h1>
							</div>
						</div>
					</div>
					
					<div class="menu-detail">
						
						<div class="row">
							
							<?php $__currentLoopData = $deserts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
							    <div class='col-sm-12'>
                            
							     <div class="col-md-3">
								     <?php if($val->picture != ''): ?>
                                        <img src='food_pic/<?php echo e($val->picture); ?>'  />
                                     <?php else: ?>
                                        <img src='food_pic/default-pic.jpg'  />
                                     <?php endif; ?>
                                 </div>
							
							     <div class="col-md-9">
								    <div class="food-detail">
									   <span class="title"><?php echo e($val->name); ?> &nbsp;<span class="price">&#8358;<?php echo e($val->price); ?></span></span>
								    </div>
                                     
                                    <div class='text-right padding-bottom-20'>
                                      <button class='text-color-white background-color-red btn margin-top-10px add-btn  ' id='cart<?php echo e($val->id); ?>' onclick='add_to_cart("food_type",<?php echo e($val->id); ?>)'>
                                          
                                          <?php if($menu_obj->checkCart('food_type',$val->id) == 0): ?>
                                                Add To Cart
                                          <?php elseif($menu_obj->checkCart('food_type',$val->id) == 1): ?>
                                                Remove item From Cart
                                          <?php endif; ?>
                                          
                                        </button>
                                 </div>
                                    
							     </div>
							    </div>
                                 
                                 
                            
				            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
											
						</div>	
                        
                          
                        <div class='pull-right'>
                            <?php if($special_food !=null && count($special_food) > 0): ?>
                                <?php echo e($starter->links()); ?>

                            <?php endif; ?>    	
				       </div>
				       
				       <?php Session::put('url','makeSalesRestaurant'); ?>
						
						
					</div>
					
				</div>
				
				</div>
				
				
				
				<div class="col-md-6">
				
				
				
				
				
				
				</div>
				
				
			
				
				
				
				
				
			</div>
		</div>
		
	</div>	
                              <!--End Content-->
                            
                        </div>

                       <div class='col-sm-12'>
                       <div class='row padding-30px'>
                       <br>
                  
                           <input type='text' id='access_token' value='<?php echo e(Session::get("token")); ?>' class='hide' />
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
    

     
    </div>
    
    <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
