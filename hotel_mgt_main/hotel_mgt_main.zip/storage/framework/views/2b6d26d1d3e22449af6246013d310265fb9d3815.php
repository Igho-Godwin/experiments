<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <?php echo $__env->make('header.nav-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container">
                <div class='row background-color-white padding-30px padding-left-30percent' style='width:100%;'>
                    
                    
                    <div>  
                       <div>
                          <h1>
                             Customer Details
                          </h1>
                       </div>
                       <br>
                       
                       <form id='edit-customerForm' enctype="multipart/form-data">
                        <div id='error' style='color:red;'>
                           
                        </div>
                        <br>
                      <div class="form-row">
                         <div class="col-sm-6">
                             <input type="text" class="form-control" id='first_name' name='first_name' placeholder="First Name" title='First Name' required='' value='<?php echo e($cus_detail->first_name); ?>'>
                         </div>
                         <div class="col-sm-6">
                             <input type="text" class="form-control" id='last_name' name='last_name' placeholder="Last Name" title='Last Name'  required='' value='<?php echo e($cus_detail->last_name); ?>'>
                         </div>
                      </div>
                           <br>
                       <div class="form-row">
                         <div class="col-sm-6">
                             <input type="text" class="form-control" id='birthday' name='birthday' placeholder="Birthday" title='Birthday' required='' value='<?php echo e(date('m-d',strtotime($cus_detail->birthday))); ?>'>
                         </div>
                         <div class="col-sm-6">
                             <input type="text" class="form-control" id='phone_number' name='phone_number' placeholder="Phone Number" title='Phone Number'  required='' value='<?php echo e($cus_detail->phone_number); ?>'>
                         </div>
                      </div>
                      <br>
                       <div class="form-row">
                         <div class="col-sm-6">
                             <input type="text" class="form-control" id='email_address' name='email_address' placeholder="Email Address" title='Email Address' required='' value='<?php echo e($cus_detail->email_address); ?>'>
                         </div>
                         <div class="col-sm-6">
                             <input type="text" class="form-control" id='address' name='address' placeholder="Address" title='Address'  required='' value='<?php echo e($cus_detail->address); ?>'>
                         </div>
                      </div>
                      <br>
                       <div class="form-row">
                         <div class="col-sm-6">
                               <select class='form-control country js-example-basic-single'   name='country' title='Country' style='width:100%;'    id='country'>
                                    <option value=''>Select Country</option>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option  <?php if($cus_detail->country == $val->name): ?> Selected  <?php endif; ?> ><?php echo e($val->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </select>
                         </div>
                         <div class="col-sm-6">
                             <select class='form-control selecti js-example-basic-single'  id='states' name='state' title='State'  data-live-search="true" style='width:100%;'  >
                                  <option><?php echo e($cus_detail->state); ?></option>
                                  <option value=''>Select State</option>
                             </select>
                         </div>
                      </div>
                      <br>
                       <div class="form-row">
                         <div class="col-sm-6">
                            <select class='form-control city js-example-basic-single'  name='city' title='City'  data-live-search="true" id='city' style='width:100%;'>
                                <option><?php echo e($cus_detail->city); ?></option>
                                <option value=''>Select City</option>
                            </select>
                         </div>
                         <div class="col-sm-6">
                              <select name='customer_type' id='customer_type' class='form-control js-example-basic-single' style='width:100%;'  >
                                        
								    <option value=''>Select Customer Type</option>
								    <option value='1' <?php if($cus_detail!==''): ?> <?php if($cus_detail->customer_type == '1'): ?> Selected <?php endif; ?> <?php endif; ?>>Individual</option>
								    <option value='2' <?php if($cus_detail!==''): ?><?php if($cus_detail->customer_type == '2'): ?> Selected <?php endif; ?> <?php endif; ?>>Company</option>
								    <option value='3' <?php if($cus_detail!==''): ?><?php if($cus_detail->customer_type == '3'): ?> Selected <?php endif; ?> <?php endif; ?>>Group</option>
								    <option value='4' <?php if($cus_detail!==''): ?><?php if($cus_detail->customer_type == '4'): ?> Selected <?php endif; ?> <?php endif; ?>>Travel Agent</option>
								    
							  </select>
                         </div>
                      </div>
                      <br>  
                       <div class="form-row">
                         <div class="col-sm-12">
                             <input type="text" class="form-control" id='discount' name='discount' placeholder="Discount" title='Discount' required='' value='<?php echo e($cus_detail->discount); ?>'>
                         </div>
                       </div>
                           
                     
                       <br> 
                    
                       <input type='text' id='access_token' value='<?php echo e(Session::get("token")); ?>' class='hide' />
                           
                       <input type='text' id='id' name='id' value='<?php echo e(Request::get("id")); ?>' class='hide' />
                       
                       <br>
                       
                       <div class="form-row">
                         <div class="col-sm-12">
                             <button type='button' id='edit-customer' class='btn-primary padding-5px width-100percent' >
                                 Submit &nbsp; <i class="fa fa-spinner fa-spin hide " aria-hidden="true"></i>
                             </button>
                         </div>
                      </div>
                   </form>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
    

     
    </div>
    
    <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
