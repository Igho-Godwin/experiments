Good day Sir/Ma,

Please click this link to change your password={{$link}}