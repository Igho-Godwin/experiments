

<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<link rel='stylesheet' href='css/pearl-hotel.css' />

<link rel='stylesheet' href='css/form-dropdown.css' />

<link rel='stylesheet' href='css/default-color.css' />



<body>
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <?php echo $__env->make('header.nav-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container">
                <div class='row background-color-white padding-30px padding-left-30percent' style='width:100%;'>
                 
                          <h1>
                             Make Sales Rooms
                          </h1>
                    </div>
               <div class="content">
		
		<div class="row">
                	
					<div class="serv-main-sec">
                        
                        <?php $__currentLoopData = $room_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
				          <div class="col-md-4">
							<div class="service-sec">
								<img src="room_type_pic/<?php echo e($val->picture); ?>" alt="">
								
								<div class="detail text-center">
								<h3><?php echo e($val->name); ?></h3>
								
								<a href="room-detail?id=<?php echo e($val->id); ?>&a=edit">view detail</a>
								</div>
								
							</div>
						  </div>
						
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
					</div>
					
					
				</div>	
                         
        <div class='pull-right text-center'>
             <?php if($room_type !=null && count($room_type) > 0): ?>
                    <?php echo e($room_type->links()); ?>

             <?php endif; ?>
        </div>
		
	</div>	
			<!-- .row end -->
                    
                    
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
    

     
    </div>
    
    <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Form Drop Down -->
<script type="text/javascript" src="js/form-dropdown.js"></script>
