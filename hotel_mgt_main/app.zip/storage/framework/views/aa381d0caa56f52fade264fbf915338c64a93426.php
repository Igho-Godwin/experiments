<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <?php echo $__env->make('header.nav-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container">
                <div class='row background-color-white padding-30px padding-left-30percent' style='width:100%;'>
                    
                    
                    <div>  
                       <div>
                          <h1>
                             Update Loyalty Details 
                          </h1>
                       </div>
                       <br>
                       
                       <form id='update-loyaltyForm' enctype="multipart/form-data">
                        <div id='error' style='color:red;'>
                           
                        </div>
                        <br>
                      <div class="form-row">
                         <div class="col-sm-6">
                             <input type="text" class="form-control" id='loyalty_value' name='loyalty_value' placeholder="Loyalty Value e.g 10" title='Loyalty Value' required='' value='<?php if($data != ""): ?><?php echo e($data->loyalty_value); ?><?php endif; ?>'>
                         </div>
                         <div class="col-sm-6">
                             <input type="text" class="form-control" id='number_of_visits' name='number_of_visits' placeholder="Number Of Visits" title='Number Of Visits'  required='' value='<?php if($data != ""): ?><?php echo e($data->visit_number); ?><?php endif; ?>'>
                         </div>
                      </div>
                      
                      <?php if($data != ''): ?>
                        
                            <input type='text' id='data' name='data' value='<?php echo e($data->id); ?>' class='hide' />
                            
                      <?php endif; ?>
                      
                      <input type='text' id='access_token' value='<?php echo e(Session::get("token")); ?>' class='hide' />
                           
                      <br>  
                       <div class="form-row">
                         <div class="col-sm-12">
                            <button type='button' id='update-loyaltyBtn' class='btn-primary padding-5px width-100percent' >
                                 Submit &nbsp; <i class="fa fa-spinner fa-spin hide " aria-hidden="true"></i>
                            </button>
                         </div>
                       </div>
                       
                       <br> 
                    
                       
                       
                       
                   </form>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
    

     
    </div>
    
    <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
