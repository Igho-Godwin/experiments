Good day Sir/Ma,

Please click this link to change your password=<?php echo e($link); ?>