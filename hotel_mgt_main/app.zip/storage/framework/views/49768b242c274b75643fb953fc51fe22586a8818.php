<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <?php echo $__env->make('header.nav-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container">
                <div class='row background-color-white padding-30px padding-left-30percent' style='width:100%;'>
                    
                    
                    <div>  
                       <div>
                          <h1>
                             Edit Store
                          </h1>
                       </div>
                       <br>
                       <form id='edit-storeForm'>
                        <div id='error' style='color:red;'>
                           
                        </div>
                      <div class="form-row">
                         <div class="col-sm-6">
                             <input type="text" class="form-control tags" id='itemName' name='itemName' value='<?php echo e($store->itemName); ?>' placeholder="Item name" title='Item name' required=''>
                         </div>
                         <div class="col-sm-6">
                             <input type="text" class="form-control" id='Quantity' name='Quantity' value='<?php echo e($store->qty); ?>' placeholder="Quantity" title='Quantity'  required=''>
                         </div>
                      </div>
                       
                       <br>
                       
                       <div class="form-row">
                         <div class="col-sm-12">
                             <input type="text" class="form-control" placeholder="Unit Price" id='UnitPrice' name='UnitPrice' value='<?php echo e($stock->getLatestUnitPrice($store->id)); ?>' title='Unit Price'  required=''>
                         </div>
                      </div>
                      
                       <br>
                      
                      <select id='departments' name='departments' class='form-control' required='' title='Departments'>
                            <option value=''>Select Departments</option>
                            
                    
                            <option value='2' <?php if($store->dept == '2'): ?> Selected <?php endif; ?>>Rooms</option>
                            <option value='3' <?php if($store->dept == '3'): ?> Selected <?php endif; ?>>Restaurant</option>
                            <option value='4' <?php if($store->dept == '4'): ?> Selected <?php endif; ?>>Bar</option>
                            <option value='5' <?php if($store->dept == '5'): ?> Selected <?php endif; ?>>Pool</option>
                            
                      </select>
                           
                      <input type='text' id='id' name='id' value='<?php echo e(Request::get("id")); ?>' class='hide' />
                           
                       <input type='text' id='access_token' value='<?php echo e(Session::get("token")); ?>' class='hide' />
                       
                       <br>
                       
                       <div class="form-row">
                         <div class="col-sm-12">
                             <button type='button' id='edit-Stock' class='btn-primary padding-5px width-100percent' >
                                 Submit &nbsp; <i class="fa fa-spinner fa-spin hide " aria-hidden="true"></i>
                             </button>
                         </div>
                      </div>
                   </form>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
    

     
    </div>
    
    <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
