<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <?php echo $__env->make('header.nav-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container">
                <div class='row background-color-white padding-30px padding-left-30percent' style='width:100%;'>
                    
                    
                    <div>  
                       <div>
                          <h1>
                            Edit Sold Food
                          </h1>
                       </div>
                       <br>
                       <form id='edit-salesRes'>
                        <div id='error' style='color:red;'>
                           
                        </div>
                      <div class="form-row">
                         <div class="col-sm-6">
                             <select class='form-control' name='food_types' id='food_types'>
                                 <?php $__currentLoopData = $food_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                    <option value='<?php echo e($val->id); ?>' <?php if($val->id == $Sales->item): ?> Selected <?php endif; ?>><?php echo e($val->name); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </select>
                         </div>
                         <div class="col-sm-6">
                             <input type="text" class="form-control" id='unit_price' name='unit_price' value='<?php echo e($Sales->price); ?>' placeholder='Unit Price' title='Unit Price'  required=''>
                         </div>
                      </div>
                       
                       <br>
                       
                       <div class="form-row">
                         <div class="col-sm-6">
                             <input type="text" class="form-control" placeholder="Quantity" id='Quantity' name='Quantity' title='Quantity'  required='' value='<?php echo e($Sales->qty); ?>'>
                         </div>
                         <div class="col-sm-6">
                             <select class='form-control' name='mode_of_payment' id='mode_of_payment'>
                                    <option value=''>Mode of Payment</option>
                                    <option value='1' <?php if($Sales->mode_of_payment == 1): ?> Selected <?php endif; ?>>POS</option>
                                    <option value='2' <?php if($Sales->mode_of_payment == 2): ?> Selected <?php endif; ?>>CASH</option>
                                    <option value='3' <?php if($Sales->mode_of_payment == 3): ?> Selected <?php endif; ?>>TRANSFER</option>
                             </select>
                         </div>
                      </div>
                           
                       <input type='text' id='access_token' value='<?php echo e(Session::get("token")); ?>' class='hide' />
                           
                       <input type='text' id='id' name='id' value='<?php echo e(Request::get("id")); ?>' class='hide' />
                       
                       <br>
                           
              
                   
                       
                       <br>
                       
                       <div class="form-row">
                         <div class="col-sm-12">
                             <button type='button' id='edit-user' class='btn-primary padding-5px width-100percent' >
                                 Submit &nbsp; <i class="fa fa-spinner fa-spin hide " aria-hidden="true"></i>
                             </button>
                         </div>
                      </div>
                   </form>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
    

     
    </div>
    
    <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
