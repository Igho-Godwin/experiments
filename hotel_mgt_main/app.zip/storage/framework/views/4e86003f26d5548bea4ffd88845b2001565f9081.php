<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<style>

.room-detail .booking-form .form .field.rooms {
    z-index: 0;
    position: relative;
}

input[type=radio]:not(:checked) {
    left: 0;
    opacity: inherit;
    position: relative;
}

</style>
 

<body>
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <?php echo $__env->make('header.nav-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container">
                <div class='row background-color-white width-100percent padding-5px'>
                   <div class='padding-30px padding-left-30percent'>
                      <h1>
                        All Room Types
                      </h1>
                   </div>
                    <br>
                   
                  <div class='col-sm-6' style='margin-top:100px;margin-bottom:60px;'  >
                            <form id='batch_update_form' >
                                
                                <fieldset>
                                    <legend>Batch Update</legend>
                                    <div class='col-sm-6'>
                                        <select name='room_no[]' id='batch_room' class='form-control'   multiple>
                                            
                                             <?php $__currentLoopData = $all_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                                 <?php $__currentLoopData = explode(',',$data->room_numbers); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                                     <option value='<?php echo e($val); ?>' ><?php echo e($val); ?></option>
                                            
                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </select>
                                    </div>
                                
                                    <div class='col-sm-6'>
                           
                                        <select name='room_condition_batch' id='batch_condition' class='room-condition-batch form-control'   >
                                            <option value='0'  style='background-color:green;color:white;'>Clean</option>
                                            <option value='1'  style='background-color:red;color:white;' >Dirty</option>
                                            <option  value='2'  style='background-color:#A52A2A;color:white;' >Occupied</option>
                                            <option value='3'  style='background-color:yellow;color:black;' >Reserved</option>
                                            <option value='4'  style='background-color:blue;color:white;' >Maintenance</option>
                                        </select>
                                    </div>
                                </fieldset>
                               
                            </form>
                        </div>
                        
                                            <!-- Button to Open the Modal -->
<button type="button" class="btn btn-primary hide" id='batch_btn' data-toggle="modal" data-target="#myModal_batch">
  Open modal
</button>

<!-- The Modal -->
<div class="modal" id="myModal_batch">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Maintenance Details</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
           <div class='row' style='padding:5px;padding-right:10px;'>
                <form id='maintenance_form_batch' autocomplete='off' >
                        
                        <div class='col-sm-12' id='error_batch' style='color:red;'>
                            
                        </div>
        
                        <div class='col-sm-12' align='center' style='margin-bottom:20px;'><b>Duration:</b></div>
                        
                        <div class='col-sm-6'>
                            <input type='text' name='from' class='datepicker form-control' placeholder='From' style='display:inline!important'  />
                        </div>
                        <div class='col-sm-6'>
                            <input type='text' name='to' class='datepicker form-control' placeholder='To' style='display:inline!important'  />
                            <input type='text' name='room_condition_batch' value='4' class='hide' />
                            <input type='text' id='rmn_no' name='room_no[]' value='' class='hide' />
                        </div>
                        
                        <div class='col-sm-12'>
                            <textarea class='form-control' name='remarks' style='margin-top:20px;' placeholder='Remarks' ></textarea>
                            <div class='pull-left' style='margin-top:20px;'>
                                <button type='button' class='btn btn-primary' onclick='updateMaintenance_batch()'>Save <i id='spin-batch' class="fa fa-spinner fa-spin hide" aria-hidden="true"></i></button>
                            </div>
                        </div>
                    
                </form>
           </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger clse" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
                    
                    
                        <br>
                    <div class="col-sm-12">
                       
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example" class="display" style='width:100%;'>
                                    <thead>
                                        <tr>
                                            <th>Room No</th>
                                            <th>Room Category</th>
                                            <th>Unit Price</th>
                                            <th>Occupied By</th>
                                            <th>Check In Date</th>
                                            <th>Check Out Date</th>
                                            <th>Added By</th>
                                            <th>Room Status</th>
                                            <th>Entry Date</th>
                                            <th class='ed'>Edit</th>
                                            <th class='ed'>delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $all_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                            <?php $__currentLoopData = explode(',',$data->room_numbers); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                                <?php $room_details = $obj->getRoomDetails($data->id); ?>
                                            
                                                <tr>
                                                    <td><?php echo e($val); ?></td>
                                                    <td><?php echo e($data->name); ?></td>
                                                    <td><?php echo e(number_format($data->unitPrice)); ?></td>
                                                    <td>
                                                        <?php if($room_details != ''): ?>
                                                            <?php echo e($obj->getCustomerFirstName($room_details->customer_id)); ?>

                                                        <?php endif; ?>    
                                                        </td>
                                                    <td>
                                                        <?php if($room_details != ''): ?>
                                                            <?php echo e(date('d-m-Y',strtotime($room_details->arrival_date))); ?>

                                                        <?php endif; ?>        
                                                    </td>
                                                    <td>
                                                        <?php if($room_details != ''): ?>
                                                            <?php echo e(date('d-m-Y',strtotime($room_details->leave_date))); ?>

                                                        <?php endif; ?>    
                                                    </td>
                                                    <td><?php echo e($user->getName($data->added_by)); ?></td>
                                                    <td>
                                                        <style>
                                                             .occupied{
                                                                /*margin: 40px;*/
                                                              /*  background: #A52A2A; */
                                                            }
                                                            
                                           </style>
                                                        
                                                        <?php $room_condition = $obj->getRoomCondition($val); ?>
                                                        
                                                        <select name='room_condition' id='b-<?php echo e($val); ?>' class='form-control room-condition' data-id='<?php echo e($val); ?>' 
                                                           
                                                           <?php if($room_condition == '0' or $room_condition == ''  ): ?>
                                                             
                                                                    style='background-color:green;color:white;'
                                                            
                                                           <?php elseif($room_condition == '1' or $room_condition == ''): ?>
                                                                
                                                                   style='background-color:red;color:white;'
                                                                   
                                                           <?php elseif($room_condition == '2' or $room_condition == ''): ?>
                                                           
                                                                   style='background-color:#A52A2A;color:white;'
                                                                   
                                                           <?php elseif($room_condition == '3' or $room_condition == ''): ?>
                                                           
                                                                   style='background-color:yellow;color:black;'
                                                                   
                                                           <?php elseif($room_condition == '4' or $room_condition == ''): ?>
                                                           
                                                                   style='background-color:blue;color:white;' 
                                                                
                                                           <?php endif; ?>
                                                        
                                                        >
                                                            <option value='0' <?php if($room_condition == '0' or $room_condition == ''  ): ?> Selected <?php endif; ?> style='background-color:green;color:white;'>Clean</option>
                                                            <option value='1' <?php if($room_condition == '1'): ?> Selected <?php endif; ?> style='background-color:red;color:white;' >Dirty</option>
                                                            <option class='occupied' value='2' <?php if($room_condition == '2'): ?> Selected <?php endif; ?> style='background-color:#A52A2A;color:white;' >Occupied</option>
                                                            <option value='3' <?php if($room_condition == '3'): ?> Selected <?php endif; ?> style='background-color:yellow;color:black;' >Reserved</option>
                                                            <option value='4' <?php if($room_condition == '4'): ?> Selected <?php endif; ?> style='background-color:blue;color:white;' >Maintenance</option>
                                                        </select>
                                                        
                                                    </td>
                                                    <td><?php echo e(date('d-m-Y H:i:s',strtotime($data->updated_at))); ?></td>
                                                    <td class='ed'>
                                                        <a href='editRoom_ty?id=<?php echo e($data->id); ?>'>Edit</a>   
                                                    </td>
                                                    <td class='ed'>
                                                        <a href='#' onClick='deleteStock(<?php echo e($data->id); ?>)'>Delete</a> 
                                                    </td>
                                                </tr>
                                                
                                                              
                    <!-- Button to Open the Modal -->
<button type="button" class="btn btn-primary hide" id='btn-<?php echo e($val); ?>' data-toggle="modal" data-target="#myModal<?php echo e($val); ?>">
  Open modal
</button>

<!-- The Modal -->
<div class="modal" id="myModal<?php echo e($val); ?>">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Maintenance Details</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
           <div class='row' style='padding:5px;padding-right:10px;'>
                <form id='maintenance_form<?php echo e($val); ?>' autocomplete='off' >
                        
                        <div class='col-sm-12' id='error<?php echo e($val); ?>' style='color:red;'>
                            
                        </div>
        
                        <div class='col-sm-12' align='center' style='margin-bottom:20px;'><b>Duration:</b></div>
                        
                        <div class='col-sm-6'>
                            <input type='text' name='from' class='datepicker form-control' placeholder='From' style='display:inline!important'  />
                        </div>
                        <div class='col-sm-6'>
                            <input type='text' name='to' class='datepicker form-control' placeholder='To' style='display:inline!important'  />
                            <input type='text' name='condition' value='4' class='hide' />
                            <input type='text' name='room_no' value='<?php echo e($val); ?>' class='hide' />
                        </div>
                        
                        <div class='col-sm-12'>
                            <textarea class='form-control' name='remarks' style='margin-top:20px;' placeholder='Remarks' ></textarea>
                            <div class='pull-left' style='margin-top:20px;'>
                                <button type='button' class='btn btn-primary' onclick='updateMaintenance(<?php echo e($val); ?>)'>Save <i id='spin-<?php echo e($val); ?>' class="fa fa-spinner fa-spin hide" aria-hidden="true"></i></button>
                            </div>
                        </div>
                    
                </form>
           </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger clse" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                             <th>Room No</th>
                                            <th>Room Category</th>
                                            <th>Unit Price</th>
                                            <th>Occupied By</th>
                                            <th>Check In Date</th>
                                            <th>Check Out Date</th>
                                            <th>Added By</th>
                                            <th>Room Status</th>
                                            <th>Entry Date</th>
                                            <th class='ed'>Edit</th>
                                            <th class='ed'>delete</th>
                                        </tr>
                                    </tfoot>
                                </table>
                                    
                                <input type='text' id='access_token' value='<?php echo e(Session::get("token")); ?>' class='hide' />
                                    
                                <div class='pull-right'>
                                      <?php if($all_items !=null && count($all_items) > 0): ?>
                                            <?php echo e($all_items->links()); ?>

                                      <?php endif; ?>
                                </div>

                                </div>
                            </div>
                        </div>
                    </div>
      

                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
      
     
    </div>
    
    <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    
    
  