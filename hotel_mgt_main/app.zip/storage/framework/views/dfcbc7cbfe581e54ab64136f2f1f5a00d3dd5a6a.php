<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 

<body>
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <?php echo $__env->make('header.nav-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container">
                <div class='row background-color-white width-100percent padding-5px'>
                   <div class='padding-30px padding-left-30percent'>
                      <h1>
                        All Drink Sales
                      </h1>
                   </div>
                    <br>
                    <div class="col-sm-12">
                        <div style='width:50%;margin-left:auto;margin-right:auto;'>
                            
                         
                            <form id='search-form' action='allSalesDrink' method='get' >
                                    <div id='error' style='color:red;'>
                           
                                    </div>
                                    <div class="form-row">
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control input-daterange-datepicker" id='date1' name='date1' value='<?php echo e(Request::get("date1")); ?>' placeholder="Date" title='Date' required=''>
                             
                                            <br />
                                        </div>
                                        <div class='col-sm-6'>
                                            
                                            <button type='submit' id='edit-drinkSales' class='btn padding-5px text-center' style='height:50px;background-color:#337ab7;color:white;' onclick='GetProfit()' >
                                                Search &nbsp; <i class="fa fa-spinner fa-spin hide " aria-hidden="true"></i>
                                            </button>
                            
                                        </div>
                                    </div>
                   
                       
                            </form>
                            <br>
                   
                            <div>
                              <?php if(isset($Income)): ?>
                                Income : &#8358;<?php echo e(number_format($Income)); ?> &nbsp; &nbsp; number of Sales : <?php echo e($sales_total); ?> 
                              <?php endif; ?>
                            </div>
                        </div>
                        <br>
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example" class="display" style='width:100%;'>
                                    <thead>
                                        <tr>
                                            <th>Drink Name</th>
                                            <th>Unit Price</th>
                                            <th>Quantity</th>
                                            <th>Mode of Payment</th>
                                            <th>Added By</th>
                                            <th>Registration Date</th>
                                            <th class='ed'>Edit</th>
                                            <th class='ed'>delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $all_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <tr>
                                              <td><?php echo e($drink_obj->getDrinkName($data->item)); ?></td>
                                              <td><?php echo e($data->price); ?></td>
                                              <td><?php echo e($data->qty); ?></td>
                                              <td><?php echo e($food_obj->getModeOfPayment($data->mode_of_payment)); ?></td>
                                              <td><?php echo e($user->getName($data->added_by)); ?></td>
                                              <td><?php echo e(date('d-m-Y H:i:s',strtotime($data->updated_at))); ?></td>
                                              <td class='ed'>
                                                <a href='editSalesDrink?id=<?php echo e($data->id); ?>'>Edit</a>   
                                              </td>
                                              <td class='ed'>
                                                  <a href='#' onClick='deleteSalesDrink(<?php echo e($data->id); ?>)'>Delete</a> 
                                              </td>
                                           </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>Drink Name</th>
                                            <th>Unit Price</th>
                                            <th>Quantity</th>
                                            <th>Mode of Payment</th>
                                            <th>Added By</th>
                                            <th>Registration Date</th>
                                            <th class='ed'>Edit</th>
                                            <th class='ed'>delete</th>
                                        </tr>
                                    </tfoot>
                                </table>
                                    
                                <input type='text' id='access_token' value='<?php echo e(Session::get("token")); ?>' class='hide' />
                                    
                                <div class='pull-right'>
                                    <?php if($all_items !=null && count($all_items) > 0): ?>
                                            <?php echo e($all_items->links()); ?>

                                    <?php endif; ?>
                                </div>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
    

     
    </div>
    
    <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
  