<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<style>

.room-detail .booking-form .form .field.rooms {
    z-index: 0;
    position: relative;
}

input[type=radio]:not(:checked) {
    left: 0;
    opacity: inherit;
    position: relative;
}

</style>
 

<body>
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <?php echo $__env->make('header.nav-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container">
                <div class='row background-color-white width-100percent padding-5px'>
                   <div class='padding-30px padding-left-30percent'>
                      <h1>
                        Best Performing Departments
                      </h1>
                   </div>
                   <br>
                   <div class='col-sm-12' style='margin-bottom:50x;'>
                       <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script>
      google.charts.load('current', {'packages':['bar','corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([

['<?php echo e(date('Y')); ?>', 


        
       'Room',

          

          


        
       'Restuarant',

          

          


        
       'Pool',

          

          


        
       'Bar'

          
          ],

['Jan',

<?php echo e($obj->getBestDeptsData('01','room')); ?>,

<?php echo e($obj->getBestDeptsData('01','restuarant')); ?>,

<?php echo e($obj->getBestDeptsData('01','pool')); ?>,

<?php echo e($obj->getBestDeptsData('01','drink')); ?>





          

          
          ] , ['Feb',



<?php echo e($obj->getBestDeptsData('02','room')); ?>,

<?php echo e($obj->getBestDeptsData('02','restuarant')); ?>,

<?php echo e($obj->getBestDeptsData('02','pool')); ?>,

<?php echo e($obj->getBestDeptsData('02','drink')); ?>

          

          
          ],

          ['Mar',



<?php echo e($obj->getBestDeptsData('03','room')); ?>,

<?php echo e($obj->getBestDeptsData('03','restuarant')); ?>,

<?php echo e($obj->getBestDeptsData('03','pool')); ?>,

<?php echo e($obj->getBestDeptsData('03','drink')); ?>


          

          
          ],

           ['Apr',



<?php echo e($obj->getBestDeptsData('04','room')); ?>,

<?php echo e($obj->getBestDeptsData('04','restuarant')); ?>,

<?php echo e($obj->getBestDeptsData('04','pool')); ?>,

<?php echo e($obj->getBestDeptsData('04','drink')); ?>


          

          
          ],

           ['May',




        
    <?php echo e($obj->getBestDeptsData('05','room')); ?>,

<?php echo e($obj->getBestDeptsData('05','restuarant')); ?>,

<?php echo e($obj->getBestDeptsData('05','pool')); ?>,

<?php echo e($obj->getBestDeptsData('05','drink')); ?>



          

          
          ],

             ['Jun',



<?php echo e($obj->getBestDeptsData('06','room')); ?>,

<?php echo e($obj->getBestDeptsData('06','restuarant')); ?>,

<?php echo e($obj->getBestDeptsData('06','pool')); ?>,

<?php echo e($obj->getBestDeptsData('06','drink')); ?>



          

          
          ],

            ['Jul',




        
       <?php echo e($obj->getBestDeptsData('07','room')); ?>,

<?php echo e($obj->getBestDeptsData('07','restuarant')); ?>,

<?php echo e($obj->getBestDeptsData('07','pool')); ?>,

<?php echo e($obj->getBestDeptsData('07','drink')); ?>



          

          
          ],

            ['Aug',


<?php echo e($obj->getBestDeptsData('08','room')); ?>,

<?php echo e($obj->getBestDeptsData('08','restuarant')); ?>,

<?php echo e($obj->getBestDeptsData('08','pool')); ?>,

<?php echo e($obj->getBestDeptsData('08','drink')); ?>


          

          
          ],


            ['Sep',



<?php echo e($obj->getBestDeptsData('09','room')); ?>,

<?php echo e($obj->getBestDeptsData('09','restuarant')); ?>,

<?php echo e($obj->getBestDeptsData('09','pool')); ?>,

<?php echo e($obj->getBestDeptsData('09','drink')); ?>



          

          
          ],

            ['Oct',


<?php echo e($obj->getBestDeptsData('10','room')); ?>,

<?php echo e($obj->getBestDeptsData('10','restuarant')); ?>,

<?php echo e($obj->getBestDeptsData('10','pool')); ?>,

<?php echo e($obj->getBestDeptsData('10','drink')); ?>


          

          
          ],

            ['Nov',


<?php echo e($obj->getBestDeptsData('11','room')); ?>,

<?php echo e($obj->getBestDeptsData('11','restuarant')); ?>,

<?php echo e($obj->getBestDeptsData('11','pool')); ?>,

<?php echo e($obj->getBestDeptsData('11','drink')); ?>



          

          
          ],

            ['Dec',


<?php echo e($obj->getBestDeptsData('12','room')); ?>,

<?php echo e($obj->getBestDeptsData('12','restuarant')); ?>,

<?php echo e($obj->getBestDeptsData('12','pool')); ?>,

<?php echo e($obj->getBestDeptsData('12','drink')); ?>



          

          
          ]






    

    
          
        ]);

        var options = {
          chart: {
            title: 'Departmental Performance For The Year <?php echo e(date('Y')); ?> based on Income',
            subtitle: 'Departments',
          }
        };

        var chart = new google.charts.Bar(document.getElementById('chart_div'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
    
      }
        
        </script>
<div class='col-sm-12' style='margin-bottom:50px;'>
    <div id="chart_div" style="width: 900px; height: 500px;"></div>
</div>
                   </div>
                    <br>
                    
                        <div class='col-sm-12 text-center' >
                   
                        <form action='bestPerformingDepts' style='display:inline-block' enctype="multipart/form-data">
                        <div id='error' style='color:red;'>
                           
                        </div>
                      <div class="form-row">
                         <div class="col-sm-12">
                             <input type="text" class="form-control input-daterange-datepicker" id='date1' name='date1' placeholder="Date" title='Date' required=''>
                             
                             <br />
                             
                             <button type='submit'  class='btn-primary padding-5px width-100percent'  >
                                 Submit &nbsp; <i class="fa fa-spinner fa-spin hide " aria-hidden="true"></i>
                             </button>
                            
                         </div>
                      </div>
                   
                       <input type='text' id='access_token' value='<?php echo e(Session::get("token")); ?>' class='hide' />
                       
                   </form>
                   
                    </div>
                    
          
                    <div class="col-sm-12">
                        
                        <?php if(Request::get('date1') == null): ?>
                             <H3 style='margin-bottom:50px;'>Data For This Month </H3>
                        <?php else: ?>
                            <H3>Data For date between <?php echo e(Request::get('date1')); ?> </H3>
                        <?php endif; ?>
                       
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example" class="display" style='width:100%;'>
                                    <thead>
                                        <tr>
                                       
                                            <th>Department</th>
                                            <th>Income</th>
                                            <th>Expenses</th>
                                            <th>Profit/Loss</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                       
                                            <tr>
                                                <td>Room</td>
                                                <td>&#8358;<?php echo e(number_format($Income['room'])); ?></td>
                                                <td>&#8358;<?php echo e(number_format($Expenses['room'])); ?></td>
                                                <td>&#8358;<?php echo e(number_format($Income['room'] - $Expenses['room'])); ?></td>
                                            </tr>
                                            
                                            <tr>
                                                <td>Bar</td>
                                                <td>&#8358;<?php echo e(number_format($Income['bar'])); ?></td>
                                                <td>&#8358;<?php echo e(number_format($Expenses['bar'])); ?></td>
                                                <td>&#8358;<?php echo e(number_format($Income['bar'] - $Expenses['bar'])); ?></td>
                                            </tr>
                                            
                                            <tr>
                                                <td>Pool</td>
                                                <td>&#8358;<?php echo e(number_format($Income['pool'])); ?></td>
                                                <td>&#8358;<?php echo e(number_format($Expenses['pool'])); ?></td>
                                                <td>&#8358;<?php echo e(number_format($Income['pool'] - $Expenses['pool'])); ?></td>
                                            </tr>
                                            
                                            <tr>
                                                <td>Restuarant</td>
                                                <td>&#8358;<?php echo e(number_format($Income['restuarant'])); ?></td>
                                                <td>&#8358;<?php echo e(number_format($Expenses['restuarant'])); ?></td>
                                                <td>&#8358;<?php echo e(number_format($Income['restuarant'] - $Expenses['restuarant'])); ?></td>
                                            </tr>
                                                
                                     
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>Department</th>
                                            <th>Income</th>
                                            <th>Expenses</th>
                                            <th>Profit/Loss</th>
                                        </tr>
                                    </tfoot>
                                </table>
                                    
                                <input type='text' id='access_token' value='<?php echo e(Session::get("token")); ?>' class='hide' />
                                    
                               
                                </div>
                            </div>
                        </div>
                    </div>
      

                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
      
     
    </div>
    
    <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    
    
  