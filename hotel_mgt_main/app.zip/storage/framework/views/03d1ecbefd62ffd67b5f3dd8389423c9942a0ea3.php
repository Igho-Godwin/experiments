<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 

<body>
    
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <?php echo $__env->make('header.nav-header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container">
                <div class='row background-color-white width-100percent padding-5px'>
                   <div class='padding-30px padding-left-38percent'>
                      <h1>
                        All Users
                      </h1>
                   </div>
                    <br>
                    <div class="col-sm-12">
                        <div class='row'>
                            <?php $__currentLoopData = $all_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class='col-sm-4 margin-bottom-20'>
                                    <div class='text-center'>
                                        <img src='<?php if($data->picture == ''): ?>images/default-pic.png <?php else: ?> user_pic/<?php echo e($data->picture); ?> <?php endif; ?>' class='border-radius-50 ' width='200' height='200' />
                                    </div>
                                    <div class='text-center'>
                                        <?php echo e($data->first_name); ?> &nbsp; <?php echo e($data->last_name); ?>

                                    </div>
                                    <div class='text-center'>
                                        <?php echo e($user->getDeptName($data->dept)); ?> Department
                                    </div>
                                    <div class='text-center'>
                                        <a href='editUser?id=<?php echo e($data->id); ?>'> Edit </a> | <a href='#' onClick='deleteUser(<?php echo e($data->id); ?>)'>Delete</a> | <a id='sus-<?php echo e($data->id); ?>' href='#' onClick='suspendUser(<?php echo e($data->id); ?>)'>
                                            <?php if($data->status == '2'): ?>
                                                Un-Suspend
                                            <?php else: ?> 
                                                 Suspend
                                            <?php endif; ?>
                                            </a>
                                    </div>
                                 
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <div class='col-sm-12'>
                               <div class='pull-right'>
                                   <?php if($all_users !=null && count($all_users) > 0): ?>
                                       <?php echo e($all_users->links()); ?>

                                   <?php endif; ?>
                               </div>
                            </div>
                            
                            <input type='text' id='access_token' value='<?php echo e(Session::get("token")); ?>' class='hide' />
                                 <!--
                                <div class="table-responsive">
                                   
                                    <table id="example" class="display" style='width:100%;'>
                                    <thead>
                                        <tr>
                                            <th>First Name</th>
                                            <th>Last Name</th>
                                            <th>Email</th>
                                            <th>Phone No</th>
                                            <th>Dept</th>
                                            <th>Added By</th>
                                            <th>Registration Date</th>
                                            <th>Edit</th>
                                            <th>delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $all_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <tr>
                                              <td><?php echo e($data->first_name); ?></td>
                                              <td><?php echo e($data->last_name); ?></td>
                                              <td><?php echo e($data->email); ?></td>
                                              <td><?php echo e($data->phone_no); ?></td>
                                              <td><?php echo e($data->dept); ?></td>
                                              <td><?php echo e($user->getName($data->added_by)); ?></td>
                                              <td><?php echo e(date('d-m-Y H:i:s',strtotime($data->created_at))); ?></td>
                                              <td>
                                                <a href='editUser?id=<?php echo e($data->id); ?>'>Edit</a>   
                                              </td>
                                              <td>
                                                  <a href='#' onClick='deleteUser(<?php echo e($data->id); ?>)'>Delete</a> 
                                              </td>
                                           </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>First Name</th>
                                            <th>Last Name</th>
                                            <th>Email</th>
                                            <th>Phone No</th>
                                            <th>Dept</th>
                                            <th>Registration Date</th>
                                            <th>Edit</th>
                                            <th>delete</th>
                                        </tr>
                                    </tfoot>
                                </table>
                                   
                                <input type='text' id='access_token' value='<?php echo e(Session::get("token")); ?>' class='hide' />
                                    
                                <div class='pull-right'>
                                    <?php if($all_users !=null && count($all_users) > 0): ?>
                                            <?php echo e($all_users->links()); ?>

                                    <?php endif; ?>
                                </div>
                                 -->
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
    

     
    </div>
    
    <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
  