<footer class="footer text-center">
    All Rights Reserved by  JOEville ITS.
</footer>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script src="admin/assets/libs/jquery/dist/jquery.min.js "></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="admin/assets/libs/popper.js/dist/umd/popper.min.js "></script>
<script src="admin/assets/libs/bootstrap/dist/js/bootstrap.min.js "></script>
<!-- apps -->
<script src="admin/dist/js/app.min.js "></script>
<script src="admin/dist/js/app.init.boxed.js "></script>
<script src="admin/dist/js/app-style-switcher.js "></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="admin/assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js "></script>
<script src="admin/assets/extra-libs/sparkline/sparkline.js "></script>
<!--Wave Effects -->
<script src="admin/dist/js/waves.js "></script>
<!--Menu sidebar -->
<script src="admin/dist/js/sidebarmenu.js "></script>
<!--Custom JavaScript -->
<script src="admin/dist/js/custom.min.js "></script>

<script src="js/add_admin.js "></script>

 <script src="cropper/cropper-master/dist/cropper.js"></script>
 
<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="//cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
<script src="//cdn.datatables.net/buttons/1.5.6/js/buttons.flash.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>

<script src="//cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js"></script>

<script src="//cdn.datatables.net/buttons/1.5.6/js/buttons.print.min."></script>
 
 <script src="//cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
  
  <script>
      $(document).ready(function() {
        $('#table').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf'
        ]
    });
      });
  </script>